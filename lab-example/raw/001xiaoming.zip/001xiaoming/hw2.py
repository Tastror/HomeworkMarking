print(int(input()))
